function edit(id, username, psw){
    const row = document.getElementById(id);
    const editAdminForm =   
                                "<form id='edit-admin-form' action='' method='POST'>"+
                                    `<td><input type='number' name='adminID' value='${id}' id='adminID'></td>`+
                                    `<td><input type='text' name='adminUsername' value='${username}' id='adminUsername'></td>`+
                                    `<td><input type='password' name='password' value='${psw}' id='password'></td>`+
                                    "<td><button type='submit' name='submit' id='submit'>Save</button></td>"+
                                "</form>";
    row.innerHTML = editAdminForm; 
}