<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "tmi2104-project";

$conn = new mysqli($host, $user, $password, $database);

if($conn -> connect_error){
    die("Connection failed: " . $conn->connect_error);
}

?>

<!DOCTYPE html>
    <head>
        <!-- <link rel="stylesheet" href="/main.css"> -->
        <link rel="stylesheet" href="admin.css">
        <link rel="stylesheet" href="admin-user.css">
        <style>@import url('https://fonts.googleapis.com/css2?family=Roboto+Mono&display=swap');</style> 
        <script src="https://cdn.jsdelivr.net/npm/chart.js@3.8.0/dist/chart.min.js"></script>
        <!-- <script src="/main.js"></script> -->
        <script src="admin.js"></script>
        <script src="admin-users.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js" integrity="sha512-z4OUqw38qNLpn1libAN9BsoDx6nbNFio5lA6CuTp9NlK83b89hgyCVq+N5FdBJptINztxn1Z3SaKSKUS5UP60Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    </head>
    <body>
        <div id="sidebar">
            <h1>Admin Dashboard</h1>
            <div class="sidebar-item sidebar-btn" id="analytics-btn" onclick="btnClickListener('analytics')">Analytics</div> 
            <div class="sidebar-item sidebar-btn active" id="users-btn" onclick="btnClickListener('users')">Users</div>
            <div class="sidebar-item sidebar-btn" id="cars-btn" onclick="btnClickListener('cars')">Cars</div>
            <div class="sidebar-item sidebar-btn" id="bookings-btn" onclick="btnClickListener('bookings')">Bookings</div>
        </div>
        <div class="mainbar" id="main-panel">
            <div class="table-container">
                <h1>Admin</h1>
                <table id="admin-table">
                    <tr>
                        <th>Admin ID</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Action</th>
                    </tr>
                    <tr>
                        <form id="add-admin-form" action="addUser.php" method="POST">
                            <td>
                                <input type="number" name="adminID" id="adminID">
                            </td>        
                            <td>
                                <input type="text" name="adminUsername" id="adminUsername">
                            </td>
                            <td>
                                <input type="password" name="password" id="password">
                            </td>
                            <td>
                                <button type="submit" name="submit" id="submit">Add Admin</button>
                            </td>
                        </form>
                    </tr>
                    <?php
                        $adminQuery  = "SELECT * FROM admin";
                        $result = $conn->query($adminQuery);
                        if($result->num_rows > 0){
                            while($row = $result->fetch_assoc()){
                                echo "  <tr id=".$row['adminID'].">
                                            <td>".$row['adminID']."</td>
                                            <td>".$row['adminUsername']."</td>
                                            <td>".$row['adminPassword']."</td>
                                            <td class='action-btn-group'>
                                                <div>
                                                    <button class='edit-btn' onclick="."edit(".$row['adminID'].","."'".$row['adminUsername']."'".","."'".$row['adminPassword']."'".")".">Edit</button>
                                                </div>
                                                <div>
                                                    <form method='POST' action='delUser.php' class='delUserForm'>
                                                        <button class='del-btn' name='del-btn' method='POST' value=".$row['adminID'].">Delete</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>";
                            }
                        }
                    ?>
                </table>
            </div>
            <div class="table-container">
            <h1>Customer</h1>
                <table id="customer-table">
                    <tr>
                        <th>Member ID</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>Email</th>
                        <th>HP</th>
                        <th>Action</th>
                    </tr>
                    <?php
                        $memberQuery  = "SELECT * FROM member";
                        $result = $conn->query($memberQuery);
                        if($result->num_rows > 0){
                            while($row = $result->fetch_assoc()){
                                echo "  <tr id=".$row['memberID'].">
                                            <td>".$row['memberID']."</td>
                                            <td>".$row['memberUsername']."</td>
                                            <td>".$row['memberPassword']."</td>
                                            <td>".$row['memberName']."</td>
                                            <td>".$row['memberGender']."</td>
                                            <td>".$row['memberAddress']."</td>
                                            <td>".$row['memberEmail']."</tr>
                                            <td>".$row['memberHP']."</td>
                                            <td class='action-btn-group'>
                                                <button class='edit-btn' onclick='edit(".$row['memberID'].")'>Edit</button>
                                                <form method='POST' action='delUser.php'>
                                                    <button class='del-btn' name='del-btn' value=".$row['memberID'].">Delete</button>
                                                </form>
                                            </td>
                                        </tr>";
                            }
                        }
                    ?>
                </table>
            </div>
        </div>
        <script>
            function debug(){
                console.log("debug");
            }
        </script>
    </body>
</html>

<?php
$conn->close;
?>