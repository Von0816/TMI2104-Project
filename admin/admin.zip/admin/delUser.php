<?php 

$server = "localhost";
$username = "root";
$password = "";
$db = "tmi2104-project";

$conn = new mysqli($server, $username, $password, $db);

if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['del-btn'])){
    $id = $_POST['del-btn'];
    $sql = "DELETE FROM admin WHERE adminID = $id";
    $result = $conn->query($sql);
    if($result){
        header('Location: admin-users.php');
        echo "<script type='text/javascript'>alert('Failed')</script>";
    }
    else {
        header('Location: admin-users.php');
        echo "<script type='text/javascript'>alert('Failed')</script>";
    }
}
else {
    echo "debug";
}
?>